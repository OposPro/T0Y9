const express = require("express");
const cors = require("cors");
const fs = require("fs");

const app = express();
const PORT = 8085;

// Libera CORS
app.use(cors());

// Rota que pega o texto da URL
app.get("/{*texto}", (req, res) => {
  let texto = req.params.texto;

  // Decodifica espaços e acentos
  texto = decodeURIComponent(texto);

  // Não salva favicon
  if (texto.includes("favicon.ico")) {
    return res.sendStatus(204);
  }

  // Salva no arquivo
  fs.appendFileSync(
    "nomes.txt",
    texto + "\n",
    "utf8"
  );

  console.log("Salvo:", texto);

  res.send(`
    <h2>Dados salvos</h2>
    <p>${texto}</p>
  `);
});

// Inicia servidor
app.listen(PORT, "0.0.0.0", () => {
  console.log(`Servidor rodando em http://localhost:${PORT}`);
});